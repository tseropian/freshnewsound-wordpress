<?php
/* 
Plugin Name: Devlounge Plugin Series
Plugin URI: http://www.devlounge.net/
Version: v1.00
Author: <a href="http://www.ronalfy.com/">Ronald Huereca</a>
Description: A sample plugin for a <a href="http://www.devlounge.net">Devlounge</a> series.
 
Copyright 2007  Ronald Huereca  (email : ron alfy [a t ] g m ail DOT com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
if (!class_exists("DevloungePluginSeries")) {
	class DevloungePluginSeries {
		function DevloungePluginSeries() { //constructor
			
		}
		function addHeaderCode() {
			?>
<!-- Devlounge Was Here -->
			<?php
		
		}
		function addContent($content = '') {
			$content .= "<p>Devlounge Was Here</p>";
			return $content;
		}
		function authorUpperCase($author = '') {
			return strtoupper($author);
		}
	
	}

} //End Class DevloungePluginSeries

if (class_exists("DevloungePluginSeries")) {
	$dl_pluginSeries = new DevloungePluginSeries();
}
//Actions and Filters	
if (isset($dl_pluginSeries)) {
	//Actions
	add_action('wp_head', array(&$dl_pluginSeries, 'addHeaderCode'), 1);
	//Filters
	add_filter('the_content', array(&$dl_pluginSeries, 'addContent')); 
	add_filter('get_comment_author', array(&$dl_pluginSeries, 'authorUpperCase'));
}

?>